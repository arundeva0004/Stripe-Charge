<?php $__env->startSection('content'); ?>

    <style>
        .section-grid{
        display: flex;
        padding-left: 25px;
        padding-right: 25px;
        }
        .grid-prod{
        flex: 1 1 auto;
        display: flex;
        flex-flow: row wrap;
        }
        .prod-grid{
            flex: 1 1 25%;
            margin:2%;
            padding:12px;
            border: 2px solid #000;
        }
    </style>
    <div style="margin-top: 10px;">
        <h3> Products </h3>
    </div>

    <div style="margin-top: 5px;">

        <div class="container">
            <!--Product Grid-->
            <div id="div1">
                <section class="section-grid">
                    <div class="grid-prod">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="prod-grid">
                                <img src="<?php echo e($product->thumbnail); ?>" width="450px" height="200px" alt="<?php echo e($product->name); ?>">

                                <h2><?php echo e($product->name); ?> <?php echo e($product->product_id); ?> </h2>

                                <div class="col-sm-12 row">
                                    <div class="col-sm-6">
                                        <h3> Rs. <?php echo e($product->price); ?> </h3>
                                    </div>
                                    <div class="col-sm-6">
                                        <a href="<?php echo e(url('/payment/'.$product->product_id)); ?>"
                                           title="View Student"><button class="btn btn-success"> Buy Now</button></a>

                                    </div>
                                </div>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.0\htdocs\stripe-charge\resources\views/products.blade.php ENDPATH**/ ?>