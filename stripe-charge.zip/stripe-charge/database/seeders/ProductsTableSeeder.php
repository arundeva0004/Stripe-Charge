<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $products = [
            ['name' => 'iPhone 9','price' => 54900,'description' => 'An apple mobile which is nothing like apple','brand' => 'Apple', "https://dummyjson.com/image/i/products/1/thumbnail.jpg"],
            ['name' => 'OPPOF19','price' => 28000,'description' => "OPPO F19 is officially announced on April 2021.",'brand' =>"OPPO","https://dummyjson.com/image/i/products/4/thumbnail.jpg" ],
            ['name' => "Huawei P30",'price' => 8990,'description' => "Huawei’s re-badged P30 Pro New Edition was officially unveiled yesterday in Germany and now the device has made its way to the UK.",'brand' => "Huawei",
                "https://dummyjson.com/image/i/products/5/thumbnail.jpg"],
            ['name' => "Orange Essence Food Flavou",'price' => 1400,'description' => "Specifications of Orange Essence Food Flavour For Cakes and Baking Food Item",'brand' => "Baking Food Items",
                "https://dummyjson.com/image/i/products/23/thumbnail.jpg"],
            ['name' => "HP Pavilion 15-DK1056WM",'price' => 10990,'description' => "HP Pavilion 15-DK1056WM Gaming Laptop 10th Gen Core i5, 8GB,
             256GB SSD, GTX 1650 4GB, Windows 10",'brand' => "HP Pavilion", "https://dummyjson.com/image/i/products/10/thumbnail.jpeg"],
            ['name' => "Infinix INBOOK",'price' => 10990,'description' =>"Infinix Inbook X1 Ci3 10th 8GB 256GB 14 Win10 Grey – 1 Year Warranty" ,
                'brand' => "Infinix", "https://dummyjson.com/image/i/products/9/thumbnail.jpg"],
            ['name' => "Microsoft Surface Laptop 4",'price' => 54990,'description' => "Style and speed. Stand out on HD video calls backed by Studio Mics.
            Capture ideas on the vibrant touchscreen.",'brand' => "Microsoft Surface","https://dummyjson.com/image/i/products/8/thumbnail.jpg"],
            ['name' => "Samsung Galaxy Book",'price' => 44499,'description' => "Samsung Galaxy Book S (2020) Laptop With Intel Lakefield Chip,
             8GB of RAM Launched",'brand' => "Samsung", "https://dummyjson.com/image/i/products/7/thumbnail.jpg"],
            ['name' => "MacBook Pro",'price' => 87749,'description' => "MacBook Pro 2021 with mini-LED display may launch between September, November",
                'brand' => "APPle","https://dummyjson.com/image/i/products/6/thumbnail.png"],
            ['name' => "Samsung Universe 9",'price' => 28249,'description' => "Samsung's new variant which goes beyond Galaxy to the Universe",'brand' => "Samsung",
                    "https://dummyjson.com/image/i/products/3/thumbnail.jpg"],

            ];
        DB::table('products')->insert($products);
    }
}
